//source of wsdlx
//wsdlx - a project that i made in visual studio using c++, i explained some of function so you can work with e-m
//made by VMmalware.
//if you skid this, you have to make your malware open source and credit me at least.
//anyways, its an example on working with these fucking rgbquad system
//if you modify the code or create your own remake, just credit me for example, you can make your source not open.
//made in 2025
//c++ is amazing.

#include <windows.h>
#include <commctrl.h>
#include <cmath>
#include <algorithm>
#include <random>

#pragma comment(lib, "comctl32.lib")

// Mode enums
enum class YMode { NONE, SIN, COS, TAN, ABS, LOG, CBRT, SQRT };
enum class XMode { NONE, SIN, COS, TAN, ABS, LOG, CBRT, SQRT };
enum class ShapeMode { CUBE, SIERPINSKI, LINES, SINE_DROP, CURSOR_CUBE };
enum class ColorMode { MONOCHROME, HUE, RANDOM_RGB, HSV, XOR_BLEND };

// Global variables
YMode g_yMode = YMode::NONE;
XMode g_xMode = XMode::NONE;
ShapeMode g_shapeMode = ShapeMode::CUBE;
ColorMode g_colorMode = ColorMode::HUE;
HWND g_hShaderWnd = NULL;
FLOAT g_speed = 0.05f;
FLOAT g_waveIntensity = 50.0f;
FLOAT g_frequency = 0.05f;
POINT g_cursorPos = { 0, 0 };
bool g_trackingCursor = false;

typedef struct {
    FLOAT h;
    FLOAT s;
    FLOAT l;
} HSL;

typedef struct {
    BYTE rgbBlue;
    BYTE rgbGreen;
    BYTE rgbRed;
    BYTE rgbReserved;
} _RGBQUAD;

namespace Colors {
    HSL rgb2hsl(RGBQUAD rgb) {
        HSL hsl;
        BYTE r = rgb.rgbRed;
        BYTE g = rgb.rgbGreen;
        BYTE b = rgb.rgbBlue;

        FLOAT _r = (FLOAT)r / 255.f;
        FLOAT _g = (FLOAT)g / 255.f;
        FLOAT _b = (FLOAT)b / 255.f;

        FLOAT rgbMin = min(min(_r, _g), _b);
        FLOAT rgbMax = max(max(_r, _g), _b);

        FLOAT fDelta = rgbMax - rgbMin;
        FLOAT deltaR, deltaG, deltaB;

        FLOAT h = 0.f;
        FLOAT s = 0.f;
        FLOAT l = (FLOAT)((rgbMax + rgbMin) / 2.f);

        if (fDelta != 0.f) {
            s = l < .5f ? (FLOAT)(fDelta / (rgbMax + rgbMin)) : (FLOAT)(fDelta / (2.f - rgbMax - rgbMin));
            deltaR = (FLOAT)(((rgbMax - _r) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaG = (FLOAT)(((rgbMax - _g) / 6.f + (fDelta / 2.f)) / fDelta);
            deltaB = (FLOAT)(((rgbMax - _b) / 6.f + (fDelta / 2.f)) / fDelta);

            if (_r == rgbMax)      h = deltaB - deltaG;
            else if (_g == rgbMax) h = (1.f / 3.f) + deltaR - deltaB;
            else if (_b == rgbMax) h = (2.f / 3.f) + deltaG - deltaR;
            if (h < 0.f)           h += 1.f;
            if (h > 1.f)           h -= 1.f;
        }

        hsl.h = h;
        hsl.s = s;
        hsl.l = l;
        return hsl;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        RGBQUAD rgb;
        FLOAT r = hsl.l;
        FLOAT g = hsl.l;
        FLOAT b = hsl.l;

        FLOAT h = hsl.h;
        FLOAT sl = hsl.s;
        FLOAT l = hsl.l;
        FLOAT v = (l <= .5f) ? (l * (1.f + sl)) : (l + sl - l * sl);

        FLOAT m, sv, fract, vsf, mid1, mid2;
        INT sextant;

        if (v > 0.f) {
            m = l + l - v;
            sv = (v - m) / v;
            h *= 6.f;
            sextant = (INT)h;
            fract = h - sextant;
            vsf = v * sv * fract;
            mid1 = m + vsf;
            mid2 = v - vsf;

            switch (sextant) {
            case 0: r = v; g = mid1; b = m; break;
            case 1: r = mid2; g = v; b = m; break;
            case 2: r = m; g = v; b = mid1; break;
            case 3: r = m; g = mid2; b = v; break;
            case 4: r = mid1; g = m; b = v; break;
            case 5: r = v; g = m; b = mid2; break;
            }
        }

        rgb.rgbRed = (BYTE)(r * 255.f);
        rgb.rgbGreen = (BYTE)(g * 255.f);
        rgb.rgbBlue = (BYTE)(b * 255.f);
        return rgb;
    }

    RGBQUAD randomRGB() {
        RGBQUAD rgb;
        rgb.rgbRed = rand() % 256;
        rgb.rgbGreen = rand() % 256;
        rgb.rgbBlue = rand() % 256;
        return rgb;
    }
}

FLOAT applyYMode(FLOAT value, FLOAT intensity, INT i, INT y) {
    FLOAT freq = g_trackingCursor ? g_frequency : 0.03f;
    switch (g_yMode) {
    case YMode::SIN: return sin(i * g_speed + y * freq * 0.003) * intensity;
    case YMode::COS: return cos(i * g_speed + y * freq * 0.003) * intensity;
    case YMode::TAN: return tan(i * g_speed + y * freq * 0.003) * intensity;
    case YMode::ABS: return fabs(i * g_speed + y * freq * 0.003) * intensity;
    case YMode::LOG: return log(i * g_speed + y * freq + 1 * 0.003) * intensity;
    case YMode::CBRT: return cbrt(i * g_speed + y * freq * 0.003) * intensity;
    case YMode::SQRT: return sqrt(i * g_speed + y * freq * 0.003) * intensity;
    default: return 0;
    }
}

FLOAT applyXMode(FLOAT value, FLOAT intensity, INT i, INT x) {
    FLOAT freq = g_trackingCursor ? g_frequency : 0.03f;
    switch (g_xMode) {
    case XMode::SIN: return sin(i * g_speed + x * freq * 0.003) * intensity;
    case XMode::COS: return cos(i * g_speed + x * freq * 0.003) * intensity;
    case XMode::TAN: return tan(i * g_speed + x * freq * 0.003) * intensity;
    case XMode::ABS: return fabs(i * g_speed + x * freq * 0.003) * intensity;
    case XMode::LOG: return log(i * g_speed + x * freq + 1 * 0.003) * intensity;
    case XMode::CBRT: return cbrt(i * g_speed + x * freq * 0.003) * intensity;
    case XMode::SQRT: return sqrt(i * g_speed + x * freq * 0.003) * intensity;
    default: return 0;
    }
}

bool sierpinski(int x, int y, int size) {
    while (size > 0) {
        if (x >= size && y >= size && x < size * 2 && y < size * 2) return false;
        x %= size * 2;
        y %= size * 2;
        size /= 2;
    }
    return true;
}

void drawCursorCube(RGBQUAD* pixels, int w, int h, int i) {
    int cubeSize = 50;
    int cubeX = g_cursorPos.x - cubeSize / 2;
    int cubeY = g_cursorPos.y - cubeSize / 2;

    for (int y = max(0, cubeY); y < min(h, cubeY + cubeSize); y++) {
        for (int x = max(0, cubeX); x < min(w, cubeX + cubeSize); x++) {
            int index = y * w + x;
            pixels[index].rgbRed = (i + x) % 256;
            pixels[index].rgbGreen = (i + y) % 256;
            pixels[index].rgbBlue = (i + x + y) % 256;
        }
    }
}

DWORD WINAPI ShaderThread(LPVOID lpParam) {
    HWND hWnd = (HWND)lpParam;
    HDC hdc = GetDC(hWnd);
    RECT rc;
    GetClientRect(hWnd, &rc);
    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;

    HDC hdcBuffer = CreateCompatibleDC(hdc);
    HBITMAP hbmBuffer = CreateCompatibleBitmap(hdc, w, h);
    SelectObject(hdcBuffer, hbmBuffer);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    RGBQUAD* pixels = NULL;
    HBITMAP hbm = CreateDIBSection(hdc, &bmi, DIB_RGB_COLORS, (void**)&pixels, NULL, 0);
    SelectObject(hdcBuffer, hbm);

    INT i = 0;
    while (GetWindowLongPtr(hWnd, GWLP_HINSTANCE)) {
        GetClientRect(hWnd, &rc);
        w = rc.right - rc.left;
        h = rc.bottom - rc.top;

        // Get cursor position relative to shader window
        POINT pt;
        GetCursorPos(&pt);
        ScreenToClient(hWnd, &pt);
        g_cursorPos = pt;
        g_frequency = 0.05f + (pt.x / (FLOAT)w) * 1.5f; // Frequency from 0.05 to 1.55

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int index = y * w + x;
                FLOAT xOffset = applyXMode(0, g_waveIntensity, i, x);
                FLOAT yOffset = applyYMode(0, g_waveIntensity, i, y);

                bool drawPixel = true;
                switch (g_shapeMode) {
                case ShapeMode::SIERPINSKI:
                    drawPixel = sierpinski(x + xOffset, y + yOffset, 256);
                    break;
                case ShapeMode::LINES:
                    drawPixel = (x + y + i) % 20 < 10;
                    break;
                case ShapeMode::SINE_DROP:
                    drawPixel = y > (h / 2) + (h / 3) * (x * g_frequency + i * g_speed);
                    break;
                case ShapeMode::CUBE:
                default:
                    g_trackingCursor = false;
                    drawPixel = true;
                    break;
                }

                if (drawPixel) {
                    int fx = (int)(x + xOffset) ^ (int)(y + yOffset);
                    HSL hslcolor;

                    switch (g_colorMode) {
                    case ColorMode::MONOCHROME:
                        pixels[index].rgbRed = pixels[index].rgbGreen = pixels[index].rgbBlue = ((x & y) + (x ^ y));
                        break;
                    case ColorMode::HUE:
                        hslcolor.h = fmod(fx / 300.f + y / (float)h * 0.1f + i / 800.f, 1.f);
                        hslcolor.s = 0.9f;
                        hslcolor.l = 0.5f;
                        pixels[index] = Colors::hsl2rgb(hslcolor);
                        break;
                    case ColorMode::RANDOM_RGB:
                        pixels[index] = Colors::randomRGB();
                        break;
                    case ColorMode::HSV:
                        hslcolor.h = fmod((x + y + i) / 800.f, 1.f);
                        hslcolor.s = 0.9f;
                        hslcolor.l = 0.5f;
                        pixels[index] = Colors::hsl2rgb(hslcolor);
                        break;
                    case ColorMode::XOR_BLEND:
                        pixels[index].rgbRed = (x ^ y) % 256;
                        pixels[index].rgbGreen = (y ^ x) % 256;
                        pixels[index].rgbBlue = (i ^ x) % 256;
                        break;
                    }
                }
                else {
                    pixels[index].rgbRed = pixels[index].rgbGreen = pixels[index].rgbBlue = 0;
                }
            }
        }

        if (g_shapeMode == ShapeMode::CURSOR_CUBE) {
            drawCursorCube(pixels, w, h, i);
        }

        BitBlt(hdc, 0, 0, w, h, hdcBuffer, 0, 0, SRCCOPY);
        i++;
        Sleep(16);
    }

    DeleteObject(hbm);
    DeleteDC(hdcBuffer);
    ReleaseDC(hWnd, hdc);
    return 0;
}

void AddButton(HWND hWnd, LPCWSTR text, int x, int y, int width, int height, int id) {
    CreateWindowW(L"BUTTON", text,
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | BS_PUSHBUTTON,
        x, y, width, height, hWnd, (HMENU)id, NULL, NULL);
}

void AddSlider(HWND hWnd, int x, int y, int width, int height, int id, int min, int max, int initial) {
    CreateWindowW(TRACKBAR_CLASS, NULL,
        WS_TABSTOP | WS_VISIBLE | WS_CHILD | TBS_AUTOTICKS | TBS_HORZ,
        x, y, width, height, hWnd, (HMENU)id, NULL, NULL);
    SendDlgItemMessage(hWnd, id, TBM_SETRANGE, TRUE, MAKELONG(min, max));
    SendDlgItemMessage(hWnd, id, TBM_SETPOS, TRUE, initial);
    SendDlgItemMessage(hWnd, id, TBM_SETTICFREQ, 10, 0);
}

void AddStaticText(HWND hWnd, LPCWSTR text, int x, int y, int width, int height, int id) {
    CreateWindowW(L"STATIC", text,
        WS_VISIBLE | WS_CHILD | SS_LEFT,
        x, y, width, height, hWnd, (HMENU)id, NULL, NULL);
}

LRESULT CALLBACK ControlPanelProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    static HWND hSpeedText, hIntensityText, hFrequencyText;

    switch (msg) {
    case WM_CREATE: {
        // Y Offset Buttons
        AddButton(hWnd, L"Y: None", 10, 10, 100, 30, 100);
        AddButton(hWnd, L"Y: Sin", 120, 10, 100, 30, 101);
        AddButton(hWnd, L"Y: Cos", 230, 10, 100, 30, 102);
        AddButton(hWnd, L"Y: Tan", 340, 10, 100, 30, 103);
        AddButton(hWnd, L"Y: Abs", 450, 10, 100, 30, 104);
        AddButton(hWnd, L"Y: Log", 560, 10, 100, 30, 105);
        AddButton(hWnd, L"Y: Cbrt", 670, 10, 100, 30, 106);

        // X Offset Buttons
        AddButton(hWnd, L"X: None", 10, 50, 100, 30, 200);
        AddButton(hWnd, L"X: Sin", 120, 50, 100, 30, 201);
        AddButton(hWnd, L"X: Cos", 230, 50, 100, 30, 202);
        AddButton(hWnd, L"X: Tan", 340, 50, 100, 30, 203);
        AddButton(hWnd, L"X: Abs", 450, 50, 100, 30, 204);
        AddButton(hWnd, L"X: Log", 560, 50, 100, 30, 205);
        AddButton(hWnd, L"X: Cbrt", 670, 50, 100, 30, 206);

        // Shape Buttons
        AddButton(hWnd, L"Cube", 10, 90, 100, 30, 300);
        AddButton(hWnd, L"Sierpinski", 120, 90, 100, 30, 301);
        AddButton(hWnd, L"Lines", 230, 90, 100, 30, 302);
        AddButton(hWnd, L"Sine Drop", 340, 90, 100, 30, 303);
        AddButton(hWnd, L"Cursor Cube", 450, 90, 100, 30, 304);

        // Color Buttons
        AddButton(hWnd, L"Monochrome cube", 10, 130, 100, 30, 400);
        AddButton(hWnd, L"Hsl", 120, 130, 100, 30, 401);
        AddButton(hWnd, L"noises", 230, 130, 100, 30, 402);
        AddButton(hWnd, L"HSV", 340, 130, 100, 30, 403);
        AddButton(hWnd, L"XOR Blend", 450, 130, 100, 30, 404);

        // Speed Slider
        AddStaticText(hWnd, L"Speed:", 10, 170, 100, 20, 500);
        AddSlider(hWnd, 120, 170, 320, 30, 501, 1, 1500, (int)(g_speed * 100));
        hSpeedText = CreateWindowW(L"STATIC", L"0.05",
            WS_VISIBLE | WS_CHILD | SS_LEFT,
            450, 170, 50, 20, hWnd, (HMENU)502, NULL, NULL);

        // Wave Intensity Slider
        AddStaticText(hWnd, L"Wave Intensity:", 10, 210, 100, 20, 503);
        AddSlider(hWnd, 120, 210, 320, 30, 504, 1, 1500, (int)g_waveIntensity);
        hIntensityText = CreateWindowW(L"STATIC", L"50.0",
            WS_VISIBLE | WS_CHILD | SS_LEFT,
            450, 210, 50, 20, hWnd, (HMENU)505, NULL, NULL);

        // Frequency Slider
        AddStaticText(hWnd, L"Base Frequency:", 10, 250, 100, 20, 506);
        AddSlider(hWnd, 120, 250, 320, 30, 507, 1, 1500, (int)(g_frequency * 100));
        hFrequencyText = CreateWindowW(L"STATIC", L"0.05",
            WS_VISIBLE | WS_CHILD | SS_LEFT,
            450, 250, 50, 20, hWnd, (HMENU)508, NULL, NULL);
        break;
    }
    case WM_HSCROLL: {
        if (lParam == (LPARAM)GetDlgItem(hWnd, 501)) { // Speed slider
            int pos = SendMessage((HWND)lParam, TBM_GETPOS, 0, 0);
            g_speed = (FLOAT)pos / 100.0f;

            WCHAR buffer[16];
            swprintf(buffer, 16, L"%.2f", g_speed);
            SetWindowText(hSpeedText, buffer);
        }
        else if (lParam == (LPARAM)GetDlgItem(hWnd, 504)) { // Wave intensity slider
            int pos = SendMessage((HWND)lParam, TBM_GETPOS, 0, 0);
            g_waveIntensity = (FLOAT)pos;

            WCHAR buffer[16];
            swprintf(buffer, 16, L"%.1f", g_waveIntensity);
            SetWindowText(hIntensityText, buffer);
        }
        else if (lParam == (LPARAM)GetDlgItem(hWnd, 507)) { // Frequency slider
            int pos = SendMessage((HWND)lParam, TBM_GETPOS, 0, 0);
            g_frequency = (FLOAT)pos / 100.0f;

            WCHAR buffer[16];
            swprintf(buffer, 16, L"%.2f", g_frequency);
            SetWindowText(hFrequencyText, buffer);
        }
        break;
    }
    case WM_COMMAND: {
        int id = LOWORD(wParam);
        // Y Offset Modes
        if (id == 100) g_yMode = YMode::NONE;
        else if (id == 101) g_yMode = YMode::SIN;
        else if (id == 102) g_yMode = YMode::COS;
        else if (id == 103) g_yMode = YMode::TAN;
        else if (id == 104) g_yMode = YMode::ABS;
        else if (id == 105) g_yMode = YMode::LOG;
        else if (id == 106) g_yMode = YMode::CBRT;

        // X Offset Modes
        else if (id == 200) g_xMode = XMode::NONE;
        else if (id == 201) g_xMode = XMode::SIN;
        else if (id == 202) g_xMode = XMode::COS;
        else if (id == 203) g_xMode = XMode::TAN;
        else if (id == 204) g_xMode = XMode::ABS;
        else if (id == 205) g_xMode = XMode::LOG;
        else if (id == 206) g_xMode = XMode::CBRT;

        // Shape Modes
        else if (id == 300) g_shapeMode = ShapeMode::CUBE;
        else if (id == 301) g_shapeMode = ShapeMode::SIERPINSKI;
        else if (id == 302) g_shapeMode = ShapeMode::LINES;
        else if (id == 303) g_shapeMode = ShapeMode::SINE_DROP;
        else if (id == 304) g_shapeMode = ShapeMode::CURSOR_CUBE;

        // Color Modes
        else if (id == 400) g_colorMode = ColorMode::MONOCHROME;
        else if (id == 401) g_colorMode = ColorMode::HUE;
        else if (id == 402) g_colorMode = ColorMode::RANDOM_RGB;
        else if (id == 403) g_colorMode = ColorMode::HSV;
        else if (id == 404) g_colorMode = ColorMode::XOR_BLEND;
        break;
    }
    case WM_CLOSE: {
        DestroyWindow(g_hShaderWnd);
        DestroyWindow(hWnd);
        break;
    }
    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK ShaderWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        CreateThread(NULL, 0, ShaderThread, hWnd, 0, NULL);
        break;
    }
    case WM_MOUSEMOVE: {
        if (g_shapeMode == ShapeMode::CURSOR_CUBE) {
            InvalidateRect(hWnd, NULL, FALSE);
        }
        break;
    }
    case WM_CLOSE: {
        DestroyWindow(hWnd);
        break;
    }
    case WM_DESTROY: {
        PostQuitMessage(0);
        break;
    }
    default:
        return DefWindowProc(hWnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR pCmdLine, int nCmdShow) {
    // Register Shader Window Class
    WNDCLASSW shaderWc = { 0 };
    shaderWc.lpfnWndProc = ShaderWndProc;
    shaderWc.hInstance = hInstance;
    shaderWc.lpszClassName = L"ShaderWindow";
    shaderWc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    RegisterClassW(&shaderWc);

    // Register Control Panel Window Class
    WNDCLASSW panelWc = { 0 };
    panelWc.lpfnWndProc = ControlPanelProc;
    panelWc.hInstance = hInstance;
    panelWc.lpszClassName = L"ControlPanel";
    panelWc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    RegisterClassW(&panelWc);

    // Calculate positions
    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    // Create Shader Window (750x500)
    int shaderWidth = 750;
    int shaderHeight = 500;
    int shaderX = (screenWidth - shaderWidth) / 2;
    int shaderY = (screenHeight - shaderHeight) / 2;

    g_hShaderWnd = CreateWindowW(
        L"ShaderWindow",
        L"Shader Visualizer",
        WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME & ~WS_MAXIMIZEBOX,
        shaderX, shaderY, shaderWidth, shaderHeight,
        NULL, NULL, hInstance, NULL
    );

    // Create Control Panel Window (890x370)
    int panelWidth = 890;
    int panelHeight = 370;
    int panelX = shaderX + shaderWidth + 10;
    int panelY = shaderY;

    HWND hPanelWnd = CreateWindowW(
        L"ControlPanel",
        L"Shader Controls",
        WS_OVERLAPPEDWINDOW & ~WS_THICKFRAME & ~WS_MAXIMIZEBOX,
        panelX, panelY, panelWidth, panelHeight,
        NULL, NULL, hInstance, NULL
    );

    if (!g_hShaderWnd || !hPanelWnd) {
        MessageBoxW(NULL, L"Window Creation Failed!", L"Error", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(g_hShaderWnd, nCmdShow);
    ShowWindow(hPanelWnd, nCmdShow);
    UpdateWindow(g_hShaderWnd);
    UpdateWindow(hPanelWnd);

    MSG msg;
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return (int)msg.wParam;
}